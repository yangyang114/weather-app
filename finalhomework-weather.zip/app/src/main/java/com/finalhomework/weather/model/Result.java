package com.finalhomework.weather.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Result {
    @SerializedName("HeWeather data service 3.0")
    private List<Weather> weatherInfoList;

    public List<Weather> getWeatherInfoList() {
        return weatherInfoList;
    }


}
