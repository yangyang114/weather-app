package com.finalhomework.weather.Entity;


public class Astro {
    /**
     *    "sr": "04:50", //日出时间
     "ss": "19:47" //日落时间
     */

    private String sr;
    private String ss;

    public String getSr() {
        return sr;
    }

    public void setSr(String sr) {
        this.sr = sr;
    }

    public String getSs() {
        return ss;
    }

    public void setSs(String ss) {
        this.ss = ss;
    }

}
