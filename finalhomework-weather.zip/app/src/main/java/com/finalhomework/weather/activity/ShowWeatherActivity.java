package com.finalhomework.weather.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.finalhomework.weather.R;
import com.finalhomework.weather.util.ChangeBackground;
import com.finalhomework.weather.util.Utility;
import com.suredigit.inappfeedback.FeedbackDialog;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.*;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

public class ShowWeatherActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView pm25;

    private TextView temp_high;

    private TextView temp_below;

    private TextView wet;

    private TextView sun_down;

    private TextView feel_temp;

    private TextView current_condition;

    private TextView temp_now;

    private TextView sun_rise;

    private Button refresh;

    private Button left_menu;

    private TextView city_name;

    private TextView day_one_time;
    private TextView day_one_temp_below;
    private TextView day_one_con;
    private TextView day_one_wind;

    private TextView day_two_time;
    private TextView day_two_temp_below;
    private TextView day_two_con;
    private TextView day_two_wind;

    private TextView day_three_time;
    private TextView day_three_temp_below;
    private TextView day_three_con;
    private TextView day_three_wind;

    private TextView day_four_time;
    private TextView day_four_temp_below;
    private TextView day_four_con;
    private TextView day_four_wind;

    private TextView day_five_time;
    private TextView day_five_temp_below;
    private TextView day_five_con;
    private TextView day_five_wind;

    private TextView suggesstion_comfort;
    private TextView suggesstion_carWash;
    private TextView suggesstion_sport;
    private TextView suggesstion_hot;
    private TextView suggesstion_air;
    private TextView suggesstion_flu;
    private TextView suggesstion_trav;
    private TextView suggesstion_uv;
    private int condition_code;
    private static String countyName;

    private int mBackKeyPressedTimes = 0;

    private LinearLayout layout;

    DrawerLayout mDrawerLayout = null;

    NavigationView navigationView;

    private FeedbackDialog feedBack;
    FloatingActionButton floatingActionButton;
    CoordinatorLayout frameLayout;
    private static String SITE="https://free-api.heweather.com/x3/weather?";
    private static String KEY="699359a18a2b4ee7beb382cf790b849e";
    private static final int SHOW_RESPONSE = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weather_layout);
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        }
        initView();
        countyName = getIntent().getStringExtra("countyName");
        if (!TextUtils.isEmpty(countyName)) {
            sendRequestWithHttpClient(countyName);
        } else {
            showWeather();
        }
    }

    /**
     * init weather view
     */
    private void initView() {
        showProgressDialog();
        //left_menu = (Button) findViewById(R.id.left_menu);
        //left_menu.setOnClickListener(this);
        city_name = (TextView) findViewById(R.id.city_name);
        refresh = (Button) findViewById(R.id.refresh);
        sun_rise = (TextView) findViewById(R.id.sun_rise);
        sun_down = (TextView) findViewById(R.id.sun_down);
        temp_now = (TextView) findViewById(R.id.temp_now);
        temp_below = (TextView) findViewById(R.id.temp_below);
        temp_high = (TextView) findViewById(R.id.temp_high);
        feel_temp = (TextView) findViewById(R.id.feel_temp);
        current_condition = (TextView) findViewById(R.id.current_condition);
        wet = (TextView) findViewById(R.id.wet);
        pm25 = (TextView) findViewById(R.id.pm25);
        suggesstion_comfort=(TextView) findViewById(R.id.suggesstion_comfort);
        suggesstion_carWash=(TextView) findViewById(R.id.suggesstion_carWash);
        suggesstion_sport=(TextView) findViewById(R.id.suggesstion_sport);
        suggesstion_hot=(TextView) findViewById(R.id.suggesstion_hot);
        suggesstion_air=(TextView) findViewById(R.id.suggesstion_air);
        suggesstion_flu=(TextView) findViewById(R.id.suggesstion_flu);
        suggesstion_uv=(TextView) findViewById(R.id.suggesstion_uv);
        //suggesstion_trav=(TextView) findViewById(R.id.suggesstion_trav);


        day_one_time = (TextView) findViewById(R.id.day_one_time);
        day_one_con = (TextView) findViewById(R.id.day_one_con);
        day_one_temp_below = (TextView) findViewById(R.id.day_one_temp_below);
        day_one_wind=(TextView) findViewById(R.id.day_one_wind);
        //    day_one_temp_high = (TextView) findViewById(R.id.day_one_temp_high);
        day_two_time = (TextView) findViewById(R.id.day_two_time);
        day_two_con = (TextView) findViewById(R.id.day_two_con);
        day_two_temp_below = (TextView) findViewById(R.id.day_two_temp_below);
        day_two_wind=(TextView) findViewById(R.id.day_two_wind);
        //    day_two_temp_high = (TextView) findViewById(R.id.day_two_temp_high);
        day_three_time = (TextView) findViewById(R.id.day_three_time);
        day_three_con = (TextView) findViewById(R.id.day_three_con);
        day_three_temp_below = (TextView) findViewById(R.id.day_three_temp_below);
        day_three_wind=(TextView) findViewById(R.id.day_three_wind);

       /* day_four_time = (TextView) findViewById(R.id.day_four_time);
        day_four_con = (TextView) findViewById(R.id.day_four_con);
        day_four_temp_below = (TextView) findViewById(R.id.day_four_temp_below);
        day_four_wind=(TextView) findViewById(R.id.day_four_wind);

        day_five_time = (TextView) findViewById(R.id.day_five_time);
        day_five_con = (TextView) findViewById(R.id.day_five_con);
        day_five_temp_below = (TextView) findViewById(R.id.day_five_temp_below);
        day_five_wind=(TextView) findViewById(R.id.day_five_wind);*/

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(countyName)) {
                    sendRequestWithHttpClient(countyName);
                    Toast.makeText(ShowWeatherActivity.this, "更新完成", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ShowWeatherActivity.this, "更新失败,请稍后重试", Toast.LENGTH_SHORT).show();
                }
            }
        });
        layout = (LinearLayout) findViewById(R.id.main_layout);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.dl_left);
        //navigationView = (NavigationView) findViewById(R.id.navigation);
        /*navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                int id = item.getItemId();
                switch (id) {
                    case R.id.change_city:
                        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(ShowWeatherActivity.this).edit();
                        editor.putBoolean("city_selected", false);
                        editor.commit();
                        Intent intent = new Intent(ShowWeatherActivity.this, ChooseAreaActivity.class);
                        startActivity(intent);
                        finish();
                        break;
                }
                return false;
            }
        });*/
        frameLayout = (CoordinatorLayout) findViewById(R.id.fablayout);
        floatingActionButton = (FloatingActionButton) findViewById(R.id.fab);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mDrawerLayout.openDrawer(Gravity.LEFT);
                SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(ShowWeatherActivity.this).edit();
                editor.putBoolean("city_selected", false);
                editor.commit();
                Intent intent = new Intent(ShowWeatherActivity.this, ChooseAreaActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    /**
     * bind data to widget
     */
    private void showWeather() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        city_name.setText(sharedPreferences.getString("city_name", "Null"));
        temp_now.setText(sharedPreferences.getString("temp_now", "Null") + "℃");
        feel_temp.setText(sharedPreferences.getString("feel_temp", "Null") + "℃");
        current_condition.setText(sharedPreferences.getString("current_condition", "Null"));

        sun_down.setText(sharedPreferences.getString("sun_down", "Null"));
        sun_rise.setText(sharedPreferences.getString("sun_rise", "Null"));
        temp_below.setText(sharedPreferences.getString("temp_below", "Null"));
        temp_high.setText(sharedPreferences.getString("temp_high", "Null") + "℃");
        wet.setText("湿度：" + sharedPreferences.getString("wet", "Null") + "%");
        pm25.setText("PM2.5：" + sharedPreferences.getString("pm25", "Null"));
        suggesstion_comfort.setText("舒适度："+sharedPreferences.getString("suggesstion_comfort","Null"));
        suggesstion_hot.setText("穿衣指数："+sharedPreferences.getString("suggesstion_hot","Null"));
        suggesstion_sport.setText("运动建议："+sharedPreferences.getString("suggesstion_sport","Null"));
        suggesstion_carWash.setText("洗车指数："+sharedPreferences.getString("suggesstion_carWash","Null"));
        suggesstion_air.setText("空气质量："+sharedPreferences.getString("suggesstion_air","Null"));
        suggesstion_flu.setText("感冒："+sharedPreferences.getString("suggesstion_flu","Null"));
        //suggesstion_trav.setText("出行建议："+sharedPreferences.getString("suggesstion_trav","Null"));
        suggesstion_uv.setText("紫外线强度："+sharedPreferences.getString("suggesstion_uv","Null"));


        day_one_time.setText("今天 "+getDate(sharedPreferences.getString("day_one_time","Null")));
        day_one_con.setText(sharedPreferences.getString("day_one_con", "NULL"));
        day_one_temp_below.setText(sharedPreferences.getString("day_one_temp_below", "NULL") + "°" + "/" + sharedPreferences.getString("day_one_temp_high", "NULL") + "°");
        day_one_wind.setText(sharedPreferences.getString("wind_one_dir","Null")+"/"+sharedPreferences.getString("wind_one_sc","Null")+"级");

        day_two_time.setText("明天 "+getDate(sharedPreferences.getString("day_two_time","Null")));
        day_two_con.setText(sharedPreferences.getString("day_two_con", "NULL"));
        day_two_temp_below.setText(sharedPreferences.getString("day_two_temp_below", "NULL") + "°" + "/" + sharedPreferences.getString("day_two_temp_high", "NULL") + "°");
        day_two_wind.setText(sharedPreferences.getString("wind_two_dir","Null")+"/"+sharedPreferences.getString("wind_two_sc","Null")+"级");

        day_three_time.setText(getWeek(sharedPreferences.getString("day_three_time", "NULL"))+" "+getDate(sharedPreferences.getString("day_three_time","Null")));
        day_three_con.setText(sharedPreferences.getString("day_three_con", "NULL"));
        day_three_temp_below.setText(sharedPreferences.getString("day_three_temp_below", "NULL") + "°" + "/" + sharedPreferences.getString("day_three_temp_high", "NULL") + "°");
        day_three_wind.setText(sharedPreferences.getString("wind_three_dir","Null")+"/"+sharedPreferences.getString("wind_three_sc","Null")+"级");

        /*day_four_time.setText(getWeek(sharedPreferences.getString("day_four_time", "NULL"))+" "+getDate(sharedPreferences.getString("day_four_time","Null")));
        day_four_con.setText(sharedPreferences.getString("day_four_con", "NULL"));
        day_four_temp_below.setText(sharedPreferences.getString("day_four_temp_below", "NULL") + "°" + "/" + sharedPreferences.getString("day_four_temp_high", "NULL") + "°");
        day_four_wind.setText(sharedPreferences.getString("wind_four_dir","Null")+"/"+sharedPreferences.getString("wind_four_sc","Null")+"级");

        day_five_time.setText(getWeek(sharedPreferences.getString("day_five_time", "NULL"))+" "+getDate(sharedPreferences.getString("day_five_time","Null")));
        day_five_con.setText(sharedPreferences.getString("day_five_con", "NULL"));
        day_five_temp_below.setText(sharedPreferences.getString("day_five_temp_below", "NULL") + "°" + "/" + sharedPreferences.getString("day_five_temp_high", "NULL") + "°");
        day_five_wind.setText(sharedPreferences.getString("wind_five_dir","Null")+"/"+sharedPreferences.getString("wind_five_sc","Null")+"级");*/
        condition_code = sharedPreferences.getInt("condition_code", 100);
        ChangeBackground background = new ChangeBackground(layout, condition_code);
        closeProgressDialog();
    }

    /**
     * about
     */


    /**
     * query Weather info
     *
     * @param countyName
     */
    private void sendRequestWithHttpClient(final String countyName){
        new Thread(new Runnable() {
            @Override
            public void run() {
                String url = SITE + "city=" + countyName + "&key=" + KEY;
                HttpClient httpClient=new DefaultHttpClient();
                HttpGet httpGet=new HttpGet(url);
                try{
                    HttpResponse httpResponse=httpClient.execute(httpGet);
                    if(httpResponse.getStatusLine().getStatusCode()==200){
                        HttpEntity entity=httpResponse.getEntity();
                        String response= EntityUtils.toString(entity,"utf-8");

                        Message message=new Message();
                        message.what=SHOW_RESPONSE;
                        message.obj=response.toString();
                        handler.sendMessage(message);
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }).start();
    }

    /**
     * receive message and show weather
     */
    private Handler handler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case SHOW_RESPONSE:
                    String response=(String)msg.obj;
                    Log.d("log",response);
                    Utility.handleWeatherResponse(ShowWeatherActivity.this, response);
                    showWeather();
                    break;
                default:
                    break;
            }
        }
    };

    /**
     * convert date to weekday
     *
     * @param sDate
     * @return
     */
    public static String getWeek(String sDate) {
        try {
            Date date = null;
            SimpleDateFormat formater = new SimpleDateFormat();
            formater.applyPattern("yyyy-MM-dd");
            date = formater.parse(sDate);
            String[] weekDays = {"周日", "周一", "周二", "周三", "周四", "周五", "周六"};
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
            if (w < 0) {
                w = 0;
            }
            return weekDays[w];
        } catch (Exception ex) {
            return null;
        }
    }
    public static String getDate(String Date)
    {


           String date=Date.substring(Date.length()-5,Date.length());
            return date;

    }
    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (v == left_menu) {
            mDrawerLayout.openDrawer(Gravity.LEFT);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (layout.getBackground() != null) {

            Bitmap oldBitmap = ((BitmapDrawable) layout.getBackground()).getBitmap();

            layout.setBackground(null);

            if (oldBitmap != null) {

                oldBitmap.recycle();

                oldBitmap = null;

            }

        }
        System.gc();
    }

    @Override
    public void onBackPressed() {
        if (mBackKeyPressedTimes == 0) {
            Toast.makeText(this, "再按一次退出程序 ", Toast.LENGTH_SHORT).show();
            mBackKeyPressedTimes = 1;
            new Thread() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } finally {
                        mBackKeyPressedTimes = 0;
                    }
                }
            }.start();
            return;
        } else {
            this.finish();
        }
        super.onBackPressed();
    }

    private ProgressDialog progressDialog;

    /**
     * show ProgressDialog
     */
    private void showProgressDialog() {
        if (progressDialog == null) {
            progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("正在加载.....");
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setCanceledOnTouchOutside(false);
        }
        progressDialog.show();
    }

    /**
     * close ProgressDialog
     */
    private void closeProgressDialog() {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }
}
