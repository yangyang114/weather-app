package com.finalhomework.weather.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;

import com.finalhomework.weather.Entity.Aqi;
import com.finalhomework.weather.Entity.Astro;
import com.finalhomework.weather.Entity.Basic;
import com.finalhomework.weather.Entity.DailyForecast;
import com.finalhomework.weather.Entity.Now;
import com.finalhomework.weather.Entity.Suggestion;
import com.finalhomework.weather.model.City;
import com.finalhomework.weather.model.County;
import com.finalhomework.weather.model.Province;
import com.finalhomework.weather.model.Result;
import com.finalhomework.weather.model.Weather;
import com.finalhomework.weather.model.WeatherDB;
import com.google.gson.Gson;

import java.util.List;


public class Utility {
    /**
     * analysis and handle the Province data from server
     */
    public synchronized static boolean handleProvincesResponse(WeatherDB weatherDB,String response){
        if(!TextUtils.isEmpty(response)){
            String[] allProvinces=response.split(",");
            if(allProvinces!=null&&allProvinces.length>0){
                for(String p:allProvinces){
                    String[] array=p.split("\\|"); //escape "|"
                    Province province=new Province();
                    province.setProvinceCode(array[0]);
                    province.setProvinceName(array[1]);
                    weatherDB.saveProvince(province);
                }
                return true;
            }
        }
        return false;
    }

    /**
     * analysis and handle the City data from server
     */
    public static boolean handlCitiesResponse(WeatherDB weatherDB,String response,int provinceId){
        if(!TextUtils.isEmpty(response)){
            String[] allCities=response.split(",");
            if(allCities!=null&&allCities.length>0){
                for(String c:allCities){
                    String[] array=c.split("\\|");
                    City city=new City();
                    city.setCityCode(array[0]);
                    city.setCityName(array[1]);
                    city.setProvinceId(provinceId);
                    weatherDB.saveCity(city);
                }
                return true;
            }
        }
        return false;
    }

    /**
     * analysis and handle County from server
     */
    public static boolean handleCountiesResponse(WeatherDB weatherDB,String response,int cityId){
        if(!TextUtils.isEmpty(response)){
            String[] allCounties=response.split(",");
            if(allCounties!=null&&allCounties.length>0){
                for(String c:allCounties){
                    String[] array=c.split("\\|");
                    County county=new County();
                    county.setCountyCode(array[0]);
                    county.setCountyName(array[1]);
                    county.setCityId(cityId);
                    weatherDB.saveCounty(county);
                }
                return true;
            }
        }
        return false;
    }

    /**
     * handle JSON response from Api
     */
    public static void handleWeatherResponse(Context context,String response){
        Gson gson=new Gson();
        Result result = gson.fromJson(response, Result.class);
        List<Weather> weatherInfoList = result.getWeatherInfoList();
        Weather weatherInfo = weatherInfoList.get(0);
        Aqi aqi=weatherInfo.getAqi();
        Now now=weatherInfo.getNow();
        Basic basic=weatherInfo.getBasic();
        Suggestion suggestion=weatherInfo.getSuggestion();
        String cityName=basic.getCity();
        String tempNow=now.getTmp();
        String feelTemp=now.getFl();
        String currentCondition=now.getCond().getTxt();
        String suggestion_comf=suggestion.comfort.txt;
        String suggestion_carwash=suggestion.carWash.txt;
        String suggestion_sport=suggestion.sport.txt;
        String suggestion_hot=suggestion.hot.txt;
        String suggestion_uv=suggestion.uv.txt;
        String suggestion_flu=suggestion.flu.txt;
        String suggestion_air=suggestion.air.txt;
        String suggestion_trav=suggestion.trav.txt;

        //initialize today
        DailyForecast dailyforecast_today =weatherInfo.getDaily_forecast().get(0);
        Astro astro_today= dailyforecast_today.getAstro();
        String sunRiseToday=astro_today.getSr();
        String sunDownToday=astro_today.getSs();
        String tempBelowToday= dailyforecast_today.getTmp().getMin();
        String tempHighToday= dailyforecast_today.getTmp().getMax();
        String wet= dailyforecast_today.getHum();
        String pm25=aqi.getCity().getPm25();

        Log.d("lo","pm2.5:"+pm25);
        int condition_code=now.getCond().getCode();

        //initialize day1
        DailyForecast dailyforecast_day1 =weatherInfo.getDaily_forecast().get(0);
        String timeDay1= dailyforecast_day1.getDate();
        String conditionDay1= dailyforecast_day1.getCond().getTxt_d();
        String tempBelowDay1= dailyforecast_day1.getTmp().getMin();
        String tempHighDay1= dailyforecast_day1.getTmp().getMax();
        String wind_dir1=dailyforecast_day1.getWind().getDir();
        String wind_sc1=dailyforecast_day1.getWind().getSc();

        //initialize day2
        DailyForecast dailyforecast_day2 =weatherInfo.getDaily_forecast().get(1);
        String timeDay2= dailyforecast_day2.getDate();
        String conditionDay2= dailyforecast_day2.getCond().getTxt_d();
        String tempBelowDay2= dailyforecast_day2.getTmp().getMin();
        String tempHighDay2= dailyforecast_day2.getTmp().getMax();
        String wind_dir2=dailyforecast_day2.getWind().getDir();
        String wind_sc2=dailyforecast_day2.getWind().getSc();

        //initialize day3
        DailyForecast dailyforecast_day3 =weatherInfo.getDaily_forecast().get(2);
        String timeDay3= dailyforecast_day3.getDate();
        String conditionDay3= dailyforecast_day3.getCond().getTxt_d();
        String tempBelowDay3= dailyforecast_day3.getTmp().getMin();
        String tempHighDay3= dailyforecast_day3.getTmp().getMax();
        String wind_dir3=dailyforecast_day3.getWind().getDir();
        String wind_sc3=dailyforecast_day3.getWind().getSc();

        //initialize day4(拓展功能----API功能不够无法获取)
       /* DailyForecast dailyforecast_day4 =weatherInfo.getDaily_forecast().get(3);
        String timeDay4= dailyforecast_day4.getDate();
        String conditionDay4= dailyforecast_day4.getCond().getTxt_d();
        String tempBelowDay4= dailyforecast_day4.getTmp().getMin();
        String tempHighDay4= dailyforecast_day4.getTmp().getMax();
        String wind_dir4=dailyforecast_day4.getWind().getDir();
        String wind_sc4=dailyforecast_day4.getWind().getSc();

        //initialize day5
        DailyForecast dailyforecast_day5 =weatherInfo.getDaily_forecast().get(4);
        String timeDay5= dailyforecast_day5.getDate();
        String conditionDay5= dailyforecast_day5.getCond().getTxt_d();
        String tempBelowDay5= dailyforecast_day5.getTmp().getMin();
        String tempHighDay5= dailyforecast_day5.getTmp().getMax();
        String wind_dir5=dailyforecast_day5.getWind().getDir();
        String wind_sc5=dailyforecast_day5.getWind().getSc();*/

        saveWeatherInfoBasic(context, cityName, tempNow, feelTemp, currentCondition,condition_code,suggestion_comf,suggestion_carwash,suggestion_sport,suggestion_hot,suggestion_air,suggestion_flu,suggestion_trav,suggestion_uv);
        //saveWeatherInfoToday(context,sunRiseToday,sunDownToday,tempBelowToday,tempHighToday,wet,pm25,suggestion_comf,suggestion_carwash,suggestion_sport,suggestion_hot);
        saveWeatherInfoToday(context,sunRiseToday,sunDownToday,tempBelowToday,tempHighToday,wet,pm25);
        saveWeatherInfoDay1(context, timeDay1, conditionDay1, tempBelowDay1, tempHighDay1,wind_dir1,wind_sc1);
        saveWeatherInfoDay2(context, timeDay2, conditionDay2, tempBelowDay2, tempHighDay2,wind_dir2,wind_sc2);
        saveWeatherInfoDay3(context, timeDay3, conditionDay3, tempBelowDay3, tempHighDay3,wind_dir3,wind_sc3);
        //saveWeatherInfoDay4(context, timeDay4, conditionDay4, tempBelowDay4, tempHighDay4,wind_dir4,wind_sc4);
        //saveWeatherInfoDay5(context, timeDay5, conditionDay5, tempBelowDay5, tempHighDay5,wind_dir5,wind_sc5);

    }

    /**
     * save Weather Info of Basic
     */
    public static void saveWeatherInfoBasic(Context context,String cityName,String tempNow,String feelTemp,String currentCondition,int condition_code,String suggestion_comf,String suggestion_carwash,String suggestion_sport,String suggestion_hot,String suggestion_air,String suggestion_uv,String suggestion_flu,String suggestion_trav){
        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(context).edit();
        editor.putBoolean("city_selected",true);
        editor.putString("city_name", cityName);
        editor.putString("temp_now", tempNow);
        editor.putString("feel_temp", feelTemp);
        editor.putString("current_condition", currentCondition);
        editor.putString("suggesstion_comfort",suggestion_comf);
        editor.putString("suggesstion_carWash",suggestion_carwash);
        editor.putString("suggesstion_hot",suggestion_hot);
        editor.putString("suggesstion_sport",suggestion_sport);
        editor.putString("suggesstion_air",suggestion_air);
        editor.putString("suggesstion_flu",suggestion_flu);
        editor.putString("suggessyion_trav",suggestion_trav);
        editor.putString("suggesstion_uv",suggestion_uv);
        editor.putInt("condition_code", condition_code);
        editor.commit();

    }

    /**
     * save weather info of Today
     */
    //public static void saveWeatherInfoToday(Context context,String sunRiseToday,String sunDownToday,String tempBelowToday,String tempHighToday,String wet,String pm25,String suggestion_comf,String suggestion_carwash,String suggestion_sport,String suggestion_hot){
    public static void saveWeatherInfoToday(Context context,String sunRiseToday,String sunDownToday,String tempBelowToday,String tempHighToday,String wet,String pm25){
        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(context).edit();
        editor.putString("sun_rise",sunRiseToday);
        editor.putString("sun_down",sunDownToday);
        editor.putString("temp_below",tempBelowToday);
        editor.putString("temp_high",tempHighToday);
        editor.putString("wet",wet);
        editor.putString("pm25",pm25);

        editor.commit();
    }

    /**
     * save weather info of Day1
     */
    public static void saveWeatherInfoDay1(Context context,String timeDay1,String conditionDay1,String tempBelowDay1,String tempHighDay1,String wind_dir1,String wind_sc1){
        SharedPreferences.Editor editor=PreferenceManager.getDefaultSharedPreferences(context).edit();
        editor.putString("day_one_time",timeDay1);
        editor.putString("day_one_con",conditionDay1);
        editor.putString("day_one_temp_below",tempBelowDay1);
        editor.putString("day_one_temp_high",tempHighDay1);
        editor.putString("wind_one_dir",wind_dir1);
        editor.putString("wind_one_sc",wind_sc1);
        editor.commit();
    }

    /**
     * save weather info of Day2
     */
    public static void saveWeatherInfoDay2(Context context,String timeDay2,String conditionDay2,String tempBelowDay2,String tempHighDay2,String wind_dir2,String wind_sc2){
        SharedPreferences.Editor editor=PreferenceManager.getDefaultSharedPreferences(context).edit();
        editor.putString("day_two_time",timeDay2);
        editor.putString("day_two_con",conditionDay2);
        editor.putString("day_two_temp_below",tempBelowDay2);
        editor.putString("day_two_temp_high",tempHighDay2);
        editor.putString("wind_two_dir",wind_dir2);
        editor.putString("wind_two_sc",wind_sc2);
        editor.commit();
    }

    /**
     * save weather info of Day3
     */
    public static void saveWeatherInfoDay3(Context context,String timeDay3,String conditionDay3,String tempBelowDay3,String tempHighDay3,String wind_dir3,String wind_sc3){
        SharedPreferences.Editor editor=PreferenceManager.getDefaultSharedPreferences(context).edit();
        editor.putString("day_three_time",timeDay3);
        editor.putString("day_three_con",conditionDay3);
        editor.putString("day_three_temp_below",tempBelowDay3);
        editor.putString("day_three_temp_high",tempHighDay3);
        editor.putString("wind_three_dir",wind_dir3);
        editor.putString("wind_three_sc",wind_sc3);
        editor.commit();
    }
    public static void saveWeatherInfoDay4(Context context,String timeDay4,String conditionDay4,String tempBelowDay4,String tempHighDay4,String wind_dir4,String wind_sc4){
        SharedPreferences.Editor editor=PreferenceManager.getDefaultSharedPreferences(context).edit();
        editor.putString("day_four_time",timeDay4);
        editor.putString("day_four_con",conditionDay4);
        editor.putString("day_four_temp_below",tempBelowDay4);
        editor.putString("day_four_temp_high",tempHighDay4);
        editor.putString("wind_four_dir",wind_dir4);
        editor.putString("wind_four_sc",wind_sc4);
        editor.commit();
    }
    public static void saveWeatherInfoDay5(Context context,String timeDay5,String conditionDay5,String tempBelowDay5,String tempHighDay5,String wind_dir5,String wind_sc5){
        SharedPreferences.Editor editor=PreferenceManager.getDefaultSharedPreferences(context).edit();
        editor.putString("day_five_time",timeDay5);
        editor.putString("day_five_con",conditionDay5);
        editor.putString("day_five_temp_below",tempBelowDay5);
        editor.putString("day_five_temp_high",tempHighDay5);
        editor.putString("wind_five_dir",wind_dir5);
        editor.putString("wind_five_sc",wind_sc5);
        editor.commit();
    }

}
