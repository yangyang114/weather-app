package com.finalhomework.weather.util;
/****向服务器请求获取相应**/
public interface HttpCallbackListener {
    void onFinish(String response);

    void onError(Exception e);
}
