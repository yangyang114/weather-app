package com.finalhomework.weather.Entity;

import com.google.gson.annotations.SerializedName;

/***suggestion : {"air":{"brf":"中","txt":"气象条件对空气污染物稀释、扩散和清除无明显影响，易感人群应适当减少室外活动时间。"},
                  "comf":{"brf":"较不舒适","txt":"白天天气多云，并且空气湿度偏大，在这种天气条件下，您会感到有些闷热，不很舒适。"},
                  "cw":{"brf":"较适宜","txt":"较适宜洗车，未来一天无雨，风力较小，擦洗一新的汽车至少能保持一天。"},
                  "drsg":{"brf":"炎热","txt":"天气炎热，建议着短衫、短裙、短裤、薄型T恤衫等清凉夏季服装。"},
                  "flu":{"brf":"少发","txt":"各项气象条件适宜，发生感冒机率较低。但请避免长期处于空调房间中，以防感冒。"},
                  "sport":{"brf":"较适宜","txt":"天气较好，较适宜进行各种运动，但考虑气温较高且湿度较大，请适当降低运动强度，并及时补充水分。"},
                  "trav":{"brf":"适宜","txt":"天气较好，但丝毫不会影响您的心情。微风，虽天气稍热，却仍适宜旅游，不要错过机会呦！"},
                  "uv":{"brf":"中等","txt":"属中等强度紫外线辐射天气，外出时建议涂擦SPF高于15、PA+的防晒护肤品，戴帽子、太阳镜。"}}
 ***/
public class Suggestion {

    //天气适宜
    @SerializedName("comf")
    public Comfort comfort;
    public class Comfort {
        //天气大致适宜情况
        public String brf;
        //具体的天气信息内容
        public String txt;
    }
    public void setComfort(Comfort comfort) {
        this.comfort = comfort;
    }

    public Comfort getComfort() {
        return comfort;
    }
    // 洗车指数
    @SerializedName("cw")
    public CarWash carWash;
    public class CarWash {
        public String brf;
        public String txt;
    }
    //穿衣指数
    @SerializedName("drsg")
    public Hot hot;
    public class Hot {
        public String brf;
        public String txt;
    }
    @SerializedName("sport")
    public Sport sport;
    public class Sport {
        public String brf;
        public String txt;
    }
    @SerializedName("air")
    public Air air;
    public class Air {
        public String brf;
        public String txt;
    }
    @SerializedName("flu")
    public Flu flu;
    public class Flu {
        public String brf;
        public String txt;
    }
    @SerializedName("uv")
    public Uv uv;
    public class Uv {
        public String brf;
        public String txt;
    }
    @SerializedName("trav")
    public Trav trav;
    public class Trav {
        public String brf;
        public String txt;
    }
}
